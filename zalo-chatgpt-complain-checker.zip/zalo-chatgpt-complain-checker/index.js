const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

app.post('/webhook', async (req, res) => {
  const message = req.body.message.text;
  const userId = req.body.sender.id;

  const gptResponse = await axios.post('https://api.openai.com/v1/chat/completions', {
    model: 'gpt-4',
    messages: [
      { role: 'system', content: 'Bạn là trợ lý kiểm tra khiếu nại khách hàng.' },
      { role: 'user', content: `Tin nhắn sau có phải là khiếu nại không? "${message}"` }
    ],
    temperature: 0.2
  }, {
    headers: {
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
    }
  });

  const reply = gptResponse.data.choices[0].message.content;
  console.log(`Phân tích GPT: ${reply}`);

  if (reply.includes('có') || reply.toLowerCase().includes('khiếu nại')) {
    console.log(`⚠️ Cảnh báo khiếu nại từ khách hàng: ${message}`);
  }

  res.sendStatus(200);
});

app.listen(PORT, () => {
  console.log(`Server đang chạy ở cổng ${PORT}`);
});
